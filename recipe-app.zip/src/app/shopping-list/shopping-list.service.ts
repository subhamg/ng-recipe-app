export class ShoppingListService {
    
}